import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import { create } from 'venom-bot';

dotenv.config();

const BOT_NAME = process.env.BOT_NAME || 'MARV-KING';
const OWNER_NAME = process.env.OWNER_NAME || 'MARV';
const PREFIX = process.env.PREFIX || '.';
const SESSION = process.env.SESSION || 'marv_king';

const MENU_PATH = path.join(process.cwd(), 'menu.json');

function loadMenu() {
  let base = { placeholderCount: 0, features: [] };
  try {
    const raw = fs.readFileSync(MENU_PATH, 'utf8');
    base = JSON.parse(raw);
  } catch (e) {
    console.warn('[WARN] Could not read menu.json, using defaults');
  }

  const features = Array.isArray(base.features) ? [...base.features] : [];
  const count = Number(base.placeholderCount || 0);

  // Autogenerate placeholders up to count
  const startIndex = features.length + 1;
  for (let i = 0; i < Math.max(0, count - features.length); i++) {
    const n = startIndex + i;
    features.push({
      cmd: `f${n}`,
      desc: `Feature #${n} — placeholder (edit menu.json to customize)`
    });
  }
  return features;
}

function chunkText(text, maxLen = 3000) {
  const chunks = [];
  let i = 0;
  while (i < text.length) {
    chunks.push(text.slice(i, i + maxLen));
    i += maxLen;
  }
  return chunks;
}

function buildMenuText(features) {
  const header = `👑 ${BOT_NAME} — Main Menu\n` +
                 `Owner: ${OWNER_NAME}\n` +
                 `Prefix: ${PREFIX}\n` +
                 `Total Features: ${features.length}\n` +
                 `———————————————\n`;

  const lines = features.map((f, idx) => {
    return `${idx + 1}) ${PREFIX}${f.cmd} — ${f.desc}`;
  });

  return header + lines.join('\n');
}

function parseCommand(body) {
  if (!body || !body.startsWith(PREFIX)) return null;
  const without = body.slice(PREFIX.length).trim();
  const [cmd, ...rest] = without.split(/\s+/);
  return { cmd: cmd.toLowerCase(), args: rest };
}

console.log(`\n[${BOT_NAME}] Starting…`);

create({
  session: SESSION,
  multidevice: true,
  headless: true,
  logQR: true
})
  .then((client) => start(client))
  .catch((err) => console.error('Failed to create client:', err));

function start(client) {
  console.log(`[${BOT_NAME}] Client ready. Waiting for messages…`);

  client.onMessage(async (message) => {
    // Only respond to chat messages (ignore status etc.)
    if (!message || !message.body) return;

    const parsed = parseCommand(message.body);
    if (!parsed) return;

    const { cmd, args } = parsed;

    // === Core Commands ===
    if (cmd === 'menu') {
      const features = loadMenu();
      const menuText = buildMenuText(features);
      for (const part of chunkText(menuText)) {
        await client.sendText(message.from, part);
      }
      return;
    }

    if (cmd === 'ping') {
      const start = Date.now();
      await client.sendText(message.from, '🏓 Pong!');
      const ms = Date.now() - start;
      await client.sendText(message.from, `⏱ Latency ~ ${ms}ms`);
      return;
    }

    if (cmd === 'owner') {
      await client.sendText(message.from, `👑 Owner: ${OWNER_NAME}\nBot: ${BOT_NAME}`);
      return;
    }

    if (cmd === 'help') {
      await client.sendText(
        message.from,
        `ℹ️ How to use ${BOT_NAME}:\n` +
        `- Type ${PREFIX}menu to view all features\n` +
        `- Commands begin with prefix "${PREFIX}"\n` +
        `- Example: ${PREFIX}ping`
      );
      return;
    }

    if (cmd === 'time') {
      const now = new Date();
      await client.sendText(message.from, `🕒 Server time: ${now.toISOString()}`);
      return;
    }

    if (cmd === 'about') {
      await client.sendText(message.from, `🤖 ${BOT_NAME} — built with venom-bot. Use responsibly.`);
      return;
    }

    // === Custom Commands (examples) ===
    if (cmd === 'echo') {
      const txt = args.join(' ') || 'Nothing to echo.';
      await client.sendText(message.from, txt);
      return;
    }

    // Unknown command fallback
    await client.sendText(
      message.from,
      `❓ Unknown command: ${PREFIX}${cmd}\nTry ${PREFIX}menu or ${PREFIX}help`
    );
  });
}
