# MARV-KING BOT

Multifunctional WhatsApp bot built with **venom-bot**.
Created by **MARV-KING** 👑

---

## ✨ Features
- `.menu` → shows 1000 features (auto-generated placeholders + real examples)
- `.ping` → quick status check
- `.help` → basic usage
- `.owner` → owner information
- Easy to extend with your own commands

---

## ⚙️ Requirements
- Node.js 18+
- WhatsApp account (use responsibly and follow WhatsApp Terms)
- Termux / Linux / macOS / Windows

---

## 📲 Termux Setup (Step-by-step)
```bash
pkg update && pkg upgrade -y
pkg install git nodejs npm -y
git clone https://github.com/YOUR-USERNAME/MARV-KING-BOT.git
cd MARV-KING-BOT
cp .env.example .env     # edit .env if you want
npm install
npm start                # scan QR in WhatsApp
```

If you don't have a repo yet:
```bash
git init
git add .
git commit -m "Initial commit - MARV KING Bot"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/MARV-KING-BOT.git
git push -u origin main
```

---

## 🚀 Deploy (Heroku/Katabump style)
- Add a `Procfile` (already included): `worker: node index.js`
- Set env vars if needed (same as `.env.example`)
- Deploy and view logs to scan QR on first run

---

## 🧩 Adding Your Own Commands
Open `index.js` and look for `// === Custom Commands ===` section.
Duplicate one of the examples and change `cmd` + logic.

---

## ⚠️ Disclaimer
This project uses **venom-bot** which automates WhatsApp Web.
Use for personal/educational purposes only. Do **not** spam or violate WhatsApp policies.
You are responsible for how you use this software.
